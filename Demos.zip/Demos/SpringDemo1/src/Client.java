
public class Client {

	public static void main(String[] args) {
		
		Department dept= new Department();
		dept.setDeptId(33);
		dept.setDeptName("Maths");
		
		Employee emp1=  new Employee(12, "Ajit", dept);
		Employee emp2= new Employee(134, "Neha", dept);
		
		Department dept1= new Department();
		dept1.setDeptId(36);
		dept1.setDeptName("Physics");
		Employee emp3= new Employee(25, "Vijaya", dept1);
		
		emp3.setDept(dept);
	}
}
