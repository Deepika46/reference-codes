
public class Employee {

	int empid;
	String empName;
	Department dept;
	

	
	Employee(int id, String name, Department dept ){
		empid=id;
		empName=name;
		this.dept=dept;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}
	
}
