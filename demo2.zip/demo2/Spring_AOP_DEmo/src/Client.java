import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.aop.Calculator;


public class Client {
public static void main(String[] args) {
    ApplicationContext context = new ClassPathXmlApplicationContext("aop.xml");
    Calculator calc = (Calculator)context.getBean("calculator");
    calc.add(34, 63);
    calc.subtract(34, 33);
    
}
}
