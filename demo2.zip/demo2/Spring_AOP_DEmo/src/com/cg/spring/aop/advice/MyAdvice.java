package com.cg.spring.aop.advice;

import org.aspectj.lang.ProceedingJoinPoint;

public class MyAdvice {


	public void beforeMethod() {
		System.out.println("Before Method Call");
	}

	public void aroundMethod(
			ProceedingJoinPoint joinpoint) {
		System.out.println
		("Around (Before) Method Call");
		try{
		joinpoint.proceed();
		}catch(Throwable t){}
		System.out.println("In excepiton");
	}

	public void afterMethod() {
		System.out.println("After Method Call");
	}
	public void abc(){
		System.out.println("you are in abc method...");
		System.out.println("now calculator class method will execute...");
	}

}



