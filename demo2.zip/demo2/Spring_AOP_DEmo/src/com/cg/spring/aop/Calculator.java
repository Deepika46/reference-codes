package com.cg.spring.aop;

public class Calculator {

	public void add(int num1 ,int num2){
		System.out.println("in add Method: "+ num1 +num2 );
	}
	public void subtract(int num1 ,int num2){
		System.out.println("in subtract Method : "+ (num1-num2) );
	}
	public void multiply(int num1 ,int num2){
		System.out.println(num1 *num2 );
	}
	public void divide(int num1 ,int num2){
		double result =(double) num1/num2;
		System.out.println(result );
	}
	
	public void findMax(int num1 ,int num2){
		int max= num1>num2?num1:num2;
		System.out.println(max);
	}
	
}
