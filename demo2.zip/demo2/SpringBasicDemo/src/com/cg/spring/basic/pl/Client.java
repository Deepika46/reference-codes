package com.cg.spring.basic.pl;


import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.spring.basic.bean.Employee;

@SuppressWarnings("deprecation")
public class Client {	
		public static void main(String[] args) {
			Resource resource= new ClassPathResource("beans.xml");
			XmlBeanFactory factory=
					new XmlBeanFactory(resource);
			
			Employee emp= (Employee) factory.getBean("emp");
	
			System.out.println(emp.getEmpId());
			System.out.println(emp.getEmpName());
			System.out.println(emp.getSalary());
			System.out.println("skills :"+emp.getSkills());
			
		}

}
