package com.cg.spring.basic.bean;

import java.util.ArrayList;

public class Employee {
	private int empId;
	private String empName;
	private double salary;
	private ArrayList<String> skills;
	
	
	public Employee(int id, String name, double sal){
		empId=id;
		empName=name;
		salary=sal;
	}
	
	public ArrayList<String> getSkills() {
		return skills;
	}

	public void setSkills(ArrayList<String> skills) {
		this.skills = skills;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		System.out.println("in setEmpId () method...");
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		System.out.println("in setEmpName () method...");
		
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		System.out.println("in setSalary () method...");
		
		this.salary = salary;
	}
	
	
}
