package com.cg.spring.bean;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Person {
	
	@NotEmpty(message="first Name can not be blank")
	@Size(max=20,min=5,message="first Name >=5 and <=20 chars")
	private String firstName;
	
	@NotEmpty(message="last Name can not be blank ")
	@Size(max=20 ,min=5,message=" last name >=5 and <=20 chars ")
	private String lastName;
	

	@Max(value=50,message="Age should be <=50 ")
	@Min(value=20,message="Age should be >=20 ")
	private int age;
	
	@Pattern(regexp="[0-9]{10}",message="Mobile no should be 10 digit ")
	private String mobile;
	
	private String address;
	private String gender;
		
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	

}
