package com.igate.spel;

public class Course {
	
	private String name;
	private String trainer;
	public String getName() {
		return name;
	}
	public String getTrainer() {
		return trainer;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	
	
	

}
