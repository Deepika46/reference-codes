package com.cg.spring.basic.bean;

public class Department {

	private String deptName;
	private int deptId;
	
	public Department() {
	}
	
	public Department(String name, int id){
		deptName= name;
		deptId=id;
	}
	
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	
	@Override
	public String toString() {
		return deptName+ "  "+ deptId;
	}
	
	
}
