package com.cg.spring.basic.bean;

public class Employee {

	String empName ;
	Department dept;
public Employee() {
	// TODO Auto-generated constructor stub
}
public void init(){
	
}
public void allocate(){
	
}
public void release(){
	
}
	public Employee(Department d){
		System.out.println("in constructor...");
		dept=d;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		System.out.println(" in setDept ()..");
		this.dept = dept;
	}
	
	
	
}
