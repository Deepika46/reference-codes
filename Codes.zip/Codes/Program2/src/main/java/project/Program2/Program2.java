package main.java.project.Program2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Program2
 */
@WebServlet("/login")
public class Program2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String username = request.getParameter("uname");
		String password = request.getParameter("pass");
		
		//Validate the credentials
		if(username.equals("admin") && password.equals("admin123")) {
			//On correct credentials Forward the request to HomeServlet
			
			request.setAttribute("message", "You are VALID User");
			//RequestDispatcher dispatcher = request.getRequestDispatcher("Home");
			//dispatcher.forward(request, response);
			
			String message = (String) request.getAttribute("message");
	   		
	   		response.setContentType("text/html");
	   		PrintWriter out = response.getWriter();
	   	
	   		out.println("</br><h3>" +message +"</h3>");
	   		
		}else {
			//On Invalid Credentials, Forward the request s  LoginErrorServlet
			request.setAttribute("message", "You are INVALID User");
			//RequestDispatcher dispatcher1 = request.getRequestDispatcher("Error");
			//dispatcher1.forward(request, response);
			
			String message = (String) request.getAttribute("message");
	   		
	   		response.setContentType("text/html");
	   		PrintWriter out = response.getWriter();
	   		
	   		out.println("<body style='background-color:#E6E6FA;'>");
	   		out.println("<h3 style='color:red'> Name :"+message+"</h3>");
	   		
		}
	}

}
