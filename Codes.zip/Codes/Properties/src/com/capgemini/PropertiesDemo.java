package com.capgemini;
import java.util.*;
import java.io.*;

public class PropertiesDemo {

	public static void main(String[] args) throws Exception {
		
		
		Properties p = new Properties();
		FileInputStream fis =new FileInputStream("abc.properties");
		p.load(fis);
		System.out.println(p);
		String s = p.getProperty("venki");
		System.out.println(s);
		p.setProperty("nag", "999999");
		Enumeration e = p.propertyNames();
		while(e.hasMoreElements())
		{
			String s1 = (String)e.nextElement();
			System.out.println(s1);
		}
		FileOutputStream fos = new FileOutputStream("xyz.properties");
		p.store(fos, "updated by ABC");
	}
	
}
