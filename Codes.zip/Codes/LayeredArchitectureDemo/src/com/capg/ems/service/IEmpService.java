package com.capg.ems.service;

import com.capg.ems.bean.Employee;

public interface IEmpService {

	public int addEmp(Employee e);
}
