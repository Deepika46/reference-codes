package com.capg.ems.dao;

import com.capg.ems.bean.Employee;

public interface IEmpDAO {
	
	public int addEmp(Employee e); 

}
