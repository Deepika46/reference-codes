package com.capg.ems.dao;

import com.capg.ems.bean.Employee;

public class EmpDAOImp implements IEmpDAO {

	@Override
	public int addEmp(Employee e) {
		// TODO Auto-generated method stub
		//jdbc with insert query return n value
		
		System.out.println("Following data stored in the database");
		System.out.println(e);
		
		return 1;
		

	}

}
