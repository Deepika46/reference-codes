import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class Address{
	private String name;
	private String street;
	private String city;
	private String state;
	private String code;
	
	Address(String n, String s, String c, String st, String cd){
		name = n;
		street = s;
		city = c;
		state = st;
		code = cd;
	}
	
	public String toString() {
		return name+ "\n" + street + "\n" +city+ " "+state+" "+code;
	}
	
}



public class MailList {
	
	public static void main(String[] args) {
		
		List<Address> m1 = new LinkedList<Address>();
		
		
		//add elements to the linked list
		m1.add(new Address("J.W. West","11 Oakfsdf", "fdsf", "fsf", "fdsf"));
		
		m1.add(new Address("dasdas. West","11 dsadf", "fdsf", "fgrtfghsf", "fdsf"));
		
		m1.add(new Address("dasdfa. West","11 Oakfsfrgtrdf", "fdshtf", "fsf", "fdsf"));
	
		Iterator<Address> itr = m1.iterator();
		while(itr.hasNext()) {
			Address element = itr.next();
			System.out.println(element + "\n");
		}
		System.out.println();
;	
	
	
	}

	
	
}
