import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

public class ListDemo {

	public static void main(String[] args) {
		
		//Collection Object
		List<Integer> list = new ArrayList<Integer>();
		
		
		
		list.add(5);
		list.add(7);
		list.add(3);
		list.add(null);
		list.add(3);
		
		list.remove(2);
		
		System.out.println(list);
		
		//System.out.println(list.size());
		
		for(Object i: list) {
			
			System.out.println(i);
			
		}
		
		
		
	}
}
