import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	
	public static void main(String[] args) {
		
		Set set =new TreeSet<String>();
		
		//Set set =new LinkedHashSet<String>();
		
		//Set set =new HashSet<String>();
		
		set.add("das");
		System.out.println(set.add("fef"));
		set.add("fsdf");
		set.add("fsz");
		//Check whether added?
		System.out.println(set.add("fsz"));//No Duplication
		
		System.out.println(set);
		
		Iterator<String> it= set.iterator();
		
		while(it.hasNext()) {
			String ename = it.next();
			
			System.out.println(ename);
			
			}
		
		
	}
}
