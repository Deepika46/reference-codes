package com.capgemini.person;
import java.math.BigInteger;
import java.util.Scanner;

public class Person {

	//Gender Enumerator
	public enum Gender {
		M,F;
	}
	
	//Person Attributes
	String firstName, lastName;
	BigInteger number;
	Gender gender;
	
	//default constructor
	public Person() {
		
	}
	
	//Parameterised Constructor
	public Person(String firstName, String lastName, Gender gender, BigInteger number){
	       // write your code here
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.number = number;			
	    }
	
	//Getter & Setters
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public BigInteger getNumber() {
		return number;
	}
	public void setNumber(BigInteger number) {
		this.number = number;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	//Function to accept contact number
	public void acceptNumber(){		
		Scanner sc = new Scanner(System.in);
		this.number = sc.nextBigInteger();		
	}
	
	//Function to display information	
	public String displayDetails(Person p) {
		return "FirstName: "+p.firstName+"\nLastName: "+p.lastName+"\nGender: "+p.gender+"\nNumber: "+p.number; 
				
	}
	
	
	
	public static void main(String[] args) {
		
		//Person  p1 = new Person("Vinayak","Gawde",Gender.M,"99999999999");
		Person p = new Person();
		
		p.setFirstName("Vinayak");
		p.setLastName("Gawde");
		p.setGender(Gender.M);
		p.acceptNumber();
		String s = p.displayDetails(p);
		System.out.println(s);
		
	}
	
	
}
