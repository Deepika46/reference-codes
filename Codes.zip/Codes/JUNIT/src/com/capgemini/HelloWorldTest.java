package com.capgemini;
import static java.lang.System.*;

import static org.junit.Assert.*;

import org.junit.Test;

public class HelloWorldTest {

	HelloWorld obj = new HelloWorld();
	
	@Test
	public void testGetName() {
		
		out.println();
		
		assertEquals("Vinayak",obj.getName());
		
		//fail("Not yet implemented");
	}

	@Test
	public void testGetBalance() {
		//fail("Not yet implemented");
		assertEquals(5000,obj.getBalance(1));
	}

}
