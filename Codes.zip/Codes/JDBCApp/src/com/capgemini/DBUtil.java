package com.capgemini;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBUtil {
	
	public static Connection getConnection() {
		
		//step 1 register or load driver
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		
		
		
/*		//-------PropertyFile Concept----------
		Properties prop = new Properties();
		
		FileInputStream fis = new FileInputStream("JDBC>properties");
		
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		
		Class.forName(driver);
		
		
		String url1 = prop.getProperty("url");
		String User = prop.getProperty("user");
		String Password = prop.getProperty("password");
		
		Connection conn2 = DriverManager.getConnection(url1, User, Password);
		*/
		
		
		//Step 2 to get the connection
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "password");
		
		return conn;
		
		
		
	}
	
	

}
