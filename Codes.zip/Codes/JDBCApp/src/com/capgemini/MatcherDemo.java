package com.capgemini;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatcherDemo {
	
	public static void main(String[] args) {
		
		Pattern p = Pattern.compile("a+");
		
		Matcher m = p.matcher("abaabaaab");
		
		while(m.find()) {
			System.out.println(m.start()+"---------"+m.group());
		}
		
		//Mobile No Pattern
		//Pattern p = Pattern.compile("[7-9][0-9]{9}");
		//Matcher m = p.matcher(args[0]);
		
		
	}

}
