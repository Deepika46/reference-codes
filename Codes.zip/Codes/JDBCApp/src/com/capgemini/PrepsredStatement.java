package com.capgemini;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class PrepsredStatement {
	
	public static void main(String[] args) {
		
		//register driver
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		//Step 2 to get the connection
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "password");
		
		String insertQuery = "insert into Employee values(?,?,?)";
		
		//String updateQuery = "update Employee set Ename= ?, sal =? where eid = ?";
		
		//String deleteQuery = "delete employee where eid = ?";
		
			PreparedStatement p = conn.prepareStatement(insertQuery);
				
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter eid");
			int id = sc.nextInt();
			
			/*p.setInt(1, 106);
				p.setString(2, 'Hruta');
				p.setDouble(3, 50000);*/
			
			//int n =	p.executeUpdate();
			
				ResultSet rs = p.executeQuery();
				
				
				while(rs.next()) {
					
					int eid = rs.getInt("eid");
					double sal = rs.getDouble("sal");
					String ename = rs.getString("ename");
					
					System.out.println(eid+ " "+sal+" "+ename);
					
				}
				
				
				
			//System.out.println(n+ " records are inserted");
			conn.close();
	}

}
