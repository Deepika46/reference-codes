package com.equals;

public class CompareString {
	
	public static void main(String args[])
	{
		String s = new String("Hello");
		String s1 = new String("Hello");
		
		System.out.println(s+" - "+s1);
		
		System.out.println(s==s1);
		
		System.out.println(s.equals(s1));
		
	}

}
