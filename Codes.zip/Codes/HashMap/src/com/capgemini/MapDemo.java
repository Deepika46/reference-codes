package com.capgemini;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {
	
	public static void main(String[] args) {
		
		Map<Integer,String> m = new HashMap<Integer,String>();
		m.put(101, "king");
		m.put(109, "raju");
		m.put(107, "adam");
		m.put(103, "scott");
		
		System.out.println(m);
		
		Set<Integer> keys = m.keySet();
		
		
		Iterator<Integer> it = keys.iterator();
		
		while(it.hasNext())
		{
			Integer key = it.next();
			String value = m.get(key);
			
			System.out.println(value);
		}
		
	}

}
