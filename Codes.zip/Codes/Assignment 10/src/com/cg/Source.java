package com.cg;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Source
{
  //write your code here
	public static void main(String[] args) {
		
		Path filePath = Paths.get("file.txt");
		FileWriter writer = null;
		try {
			writer = new FileWriter("output.txt");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		Scanner sc;
		try {
			sc = new Scanner(filePath);
			List<String> integers = new ArrayList<>();
			while (sc.hasNext()) {
				  if (sc.hasNextInt()) {
			        integers.add(sc.next());
			    } else if(sc.delimiter() != null){
			       integers.add(" ");
			    }
 
			}
			
			for (String string : integers) {
				System.out.println(string);
			}
			
			try ( BufferedWriter bw = 
					new BufferedWriter (new FileWriter ("output.txt")) ) 
			{			
				for (String line : integers) {
					bw.write (line + "\n");
				}
				
				bw.close ();
				
			} catch (IOException e) {
				e.printStackTrace ();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
}

