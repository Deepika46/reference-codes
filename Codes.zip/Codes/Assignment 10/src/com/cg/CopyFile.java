package com.cg;

import java.io.*;
public class CopyFile {

    static void fileWrite(int n, FileOutputStream out) throws IOException {
    	
        int temp = n;
        int rev=0;
        while(temp!=0) {
                rev = rev*10 + temp%10;
                temp=temp/10;
        }
            
        while(rev!=0) {
            out.write(48+rev%10);
            rev=rev/10;
        }
        
        out.write(32);
    }//end of the fileWrite
    
   public static void main(String args[]) throws IOException {  
      FileInputStream in = null;
      FileOutputStream out = null;
      
      int i=0;
      int j=0;
      int flag=0;
      
      try {
          in = new FileInputStream("input.txt");
          out = new FileOutputStream("output.txt");
          
          int c;
          
          while((c = in.read()) != -1) {
              c=c-48;
              
              if(c == -4 || c == -49) {
                  flag=1;
              }
              else {
                  if(i==0) i=c;
                  else i = i*10 + c;
              }
              
              if(flag==1) {                  
                  if(i%2==0) {
                        int temp = i;
                        fileWrite(i,out);
                        
                  }
                  
                  i=0;
                  flag=0;
              }     
          }
          
          if(i%2==0) {
                int temp = i;
                fileWrite(i,out);
                
            }
      }//end of try
      catch(Exception e) {
    	  System.out.println("Some error found.\n");
      }
      
      in.close();
      out.close();
   }//end of the main
}///end of the CopyFile Class