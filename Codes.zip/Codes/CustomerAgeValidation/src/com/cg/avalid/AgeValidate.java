package com.cg.avalid;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class AgeValidate
 */
@WebServlet("/ValidateAge")
public class AgeValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AgeValidate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			
		
		String pname = request.getParameter("pName");
	
		String age = request.getParameter("pAge");
		
		String gender = request.getParameter("gender");
		
		String result;
		
		int iAge = Integer.parseInt(age);
		
		
		if(iAge>=18)
		{
			result = "Welcome "+pname+". You are Eligible for Voting";
			request.setAttribute("result", result);
			RequestDispatcher rd = request.getRequestDispatcher("/Success");
			rd.forward(request, response);
		}
		else
		{
			result = "Welcome "+pname+". You are NOT Eligible for Voting";
			request.setAttribute("result", result);
			RequestDispatcher rd = request.getRequestDispatcher("/Failure");
			rd.forward(request, response);
		}
		
		
		
		
		
		//response.sendRedirect("Success");
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
