package com.capgemini;
import java.util.List;
import java.util.ArrayList ;

class Source{
	
	//method to remove common elements from the list1
	public List<String> removeElements(List<String> list1,List<String> list2){
		//remove complete collection passed as a parameter
		list1.removeAll(list2);		
		return list1;
		//Write your code here
	}
	
	public static void main(String[] args) {
		
		//Create new list list1
		List<String> list1 = new ArrayList<String>();
		
		//Add elements in the list1
		list1.add("Vinayak");
		list1.add("Swastika");
		list1.add("Shreya");
		list1.add("Radha");
		list1.add("Yogesh");
		
		
		//Create new list list2
		List<String> list2 = new ArrayList<String>();
		
		//Add elements in the list1
		list2.add("Vinayak");
		list2.add("Swastika");
		list2.add("Shreya");
		
		Source s = new Source();
		s.removeElements(list1, list2);
		System.out.println(list1);		
	}
}