package com.capgemini;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileReaderA {
	
	public static void main(String[] args) throws IOException{
		
		File file = new File("E:\\TestFile.txt");		
		FileReader fr = new FileReader(file);
		
		/*char[] arr = new char[(int)file.length()];
		
		fr.read(arr,5,20);
		System.out.println(arr);*/
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Anything");
		
		String str = sc.nextLine();
		fr.write(str);
		
		fr.close();
		System.out.println("done");
		
	}

}
