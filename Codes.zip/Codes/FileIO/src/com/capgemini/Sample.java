package com.capgemini;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Sample {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		/*Employee emp =new Employee();
		emp.setId(34);
		emp.setName("Vinayak");
		emp.setAge(21);
		emp.setGender("Male");
		emp.setSalary(20000);
		
		FileOutputStream fos = new FileOutputStream("E:\\TestFile4.txt");
		
		ObjectOutputStream out = new ObjectOutputStream(fos);
		
		out.writeObject(emp);
		
		System.out.println("Object Written");*/
		
		FileInputStream fis = new FileInputStream("E:\\TestFile4.txt");
		ObjectInputStream in = new ObjectInputStream(fis);
		
		Employee emp = (Employee) in.readObject();
		System.out.println(emp);
	}

}
