package com.capgemini;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileOutput {
	
	public static void main(String[] args) throws IOException {
		
		FileOutputStream fos = new FileOutputStream("E:\\TestFile2.txt");
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter Anything");
		String str = sc.nextLine();
		//Read one one character
		/*for(int i=0;i<str.length();i++) {
			fos.write(str.charAt(i));
		}
		
		fos.close();*/
		
		//str.getBytes() return array of the bytes
		fos.write(str.getBytes());
		fos.close();
		
		
		//from one position to other
		/*fos.write(str.getBytes(),5,10);
		fos.close();*/
		
		
	}
}


