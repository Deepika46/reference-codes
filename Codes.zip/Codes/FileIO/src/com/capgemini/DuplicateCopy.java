package com.capgemini;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DuplicateCopy {
	
	public static void main(String[] args) throws IOException {
		
		//can copy any file
		FileInputStream fis = new FileInputStream("E:\\TestFile.txt");
		FileOutputStream fos = new FileOutputStream("E:\\TestFile3.txt");
		
		/*int c;
		while((c = fis.read())!=-1) {
			fos.write(c);
		}*/
		
		byte[] buffer = new byte[fis.available()];
		fis.read(buffer);
		fos.write(buffer);
		
		fos.close();
		fis.close();
	}

}
