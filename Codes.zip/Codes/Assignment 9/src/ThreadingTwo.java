
public class ThreadingTwo {
	
	public static void main(String[] args) {
		
		Object lock = new Object();
		
		ReaderThread rt = new ReaderThread();
		Thread t = new Thread(rt);
		t.start();
		
		WriterThread wt = new WriterThread();
		Thread t1 = new Thread(wt);
		t1.start();
		
		
		
		
	}

}

//you can make necessary imports

