import java.io.FileWriter;
import java.io.IOException;

// you can make necessary imports

class WriterThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			FileWriter fr = new FileWriter("output.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
  // complete this class
}