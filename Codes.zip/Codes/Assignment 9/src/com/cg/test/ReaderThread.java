package com.cg.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;

public class ReaderThread implements Runnable{
	protected BlockingQueue<String> blockingQueue = null;

	public ReaderThread(BlockingQueue<String> blockingQueue){
		this.blockingQueue = blockingQueue;     
	}

	@Override
	public void run() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File("C:/Users/Vijay/eclipse-workspace/Assignment 9/src/com/cg/test/input.txt")));
            String buffer =null;
            while((buffer=br.readLine())!=null){
                blockingQueue.put(buffer);
            }
            blockingQueue.put("EOF");  //When end of file has been reached

        } catch (FileNotFoundException e) {

            System.out.println("File Not Found");
        } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }//end of the finally

	}//end of run()

}//end of the class