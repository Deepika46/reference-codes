import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReaderThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		FileReader fr = null;
		try {
			fr = new FileReader("input.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
	        try {
	        	if (fr != null) {
				fr.close();
			} }catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    
		}
		
	

// complete this class

	}
}