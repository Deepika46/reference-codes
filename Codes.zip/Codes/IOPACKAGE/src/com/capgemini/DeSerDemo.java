package com.capgemini;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerDemo {
	
	public static void main(String[] args) throws ClassNotFoundException {
		
		FileInputStream fis;
		try {
			
			fis = new FileInputStream("customer.ser");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Customer c = (Customer) ois.readObject();
			
			System.out.println(c.getCid());
			System.out.println(c.getCname());
			System.out.println(c.getAmount());
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
