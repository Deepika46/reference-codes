package com.capgemini;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PathDemo {
	
	public static void main(String[] args) throws IOException {
		
Path javahome = Paths.get("E:/DOCUMENTS/ASSIGNMENT");

DirectoryStream<Path> contents = Files.newDirectoryStream(javahome);

for (Path content : contents) {
	
	System.out.println(content.getFileName());
	
}

contents.close();

		
		/*System.out.println(javahome.getNameCount());
		System.out.println(javahome.getRoot());
		System.out.println(javahome.getName(0));
		System.out.println(javahome.getName(1));
		System.out.println(javahome.getFileName());
		System.out.println(javahome.getParent());*/
	}
}
