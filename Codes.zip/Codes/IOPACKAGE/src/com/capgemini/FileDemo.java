package com.capgemini;

import java.io.File;
import java.util.Scanner;

public class FileDemo {
	
	String fname;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String fname = sc.nextLine();
		File f = new File(fname);
		System.out.println("File Name : "+f.getName());
		System.out.println("Parent Directorye Name : "+f.getParent());
		System.out.println("Absolute Path Name : "+f.getAbsolutePath());
		System.out.println("File modified last on : "+String.valueOf(f.lastModified()));
		System.out.println("File length : "+f.length());
		System.out.println("File Readable? : "+(f.canRead()? "true":"false"));
		
		
		
	}

}
