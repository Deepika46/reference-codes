package com.capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BRDemo {
	
	public static void main(String[] args) {
		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		try {
			/*char c = (char) br.read();
			System.out.println(c);*/
			System.out.println("Enter your name : ");
			String name = br.readLine();
			System.out.println(name);
			
			String sal = br.readLine();
			int salary = Integer.parseInt(sal);
			
			System.out.println(salary+1000);
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
