package com.capgemini;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerDemo {
	
	public static void main(String[] args) {
		
		try {
			FileOutputStream fos = new FileOutputStream("customer.ser");
			
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			Customer c = new Customer();
			c.setCid(101);
			c.setCname("Vinayak");
			c.setAmount(20000);
			
			oos.writeObject(c);
			
			System.out.println("Object is Written");
					
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
