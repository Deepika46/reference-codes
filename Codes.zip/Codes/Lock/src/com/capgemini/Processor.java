package com.capgemini;

import java.util.Scanner;

public class Processor {
	
	public void produce() throws InterruptedException{
		
		synchronized (this) {
			System.out.println("Producer Started.....");			
			//Release the lock
			//wait can be called within synchronized block only
			wait();
			System.out.println("Producer Resumed.....");
			
		}
	}
	
	public void consume() throws InterruptedException{
		
		Thread.sleep(2000);
		
		Scanner sc = new Scanner(System.in);
		
		synchronized (this) {
			System.out.println("Waiting for return key......");			
			//Release the lock
			sc.nextLine();
			System.out.println("Return key pressed");
			notify();
			Thread.sleep(5000);
			System.out.println("Consumer Comlpeted");
			
		}
	}
	
	/*public void operate() throws InterruptedException{
		
		Thread.sleep(4000);
		
		Scanner sc = new Scanner(System.in);
		
		synchronized (this) {
			System.out.println("Producer Started.....");			
			//Release the lock
			wait();
			System.out.println("Producer Resumed.....");
			
		}
	}*/

}
