
public class MyThreadRunnable implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("run() called by start() used Runnable");
	}
	
	public static void main(String[] args) {
		
		
		MyThreadRunnable mt = new MyThreadRunnable();
		Thread t = new Thread(mt);
		//Thread t = new Thread(new Runnable(){});
		
		
		t.start();
		System.out.println(t);
	}

}
