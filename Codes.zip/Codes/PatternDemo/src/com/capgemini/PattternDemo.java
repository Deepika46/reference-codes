package com.capgemini;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PattternDemo {
	
	public static void main(String[] args) {
		
		
		//Part1
		/*String input = "This is Java";
		String pattern = "Java";
		
		Boolean b = Pattern.matches(input, pattern);
		System.out.println(b);*/
		
		
		//Part2 - Pattern class
		/*Pattern p = Pattern.compile("a+b");
		
		Matcher m = p.matcher("fsdadbgfdg");
		
		boolean b1 = m.find();
		
		System.out.println(b1);*/
		
		
		
		
	}

}
