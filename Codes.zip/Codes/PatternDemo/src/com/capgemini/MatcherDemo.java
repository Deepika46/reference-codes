package com.capgemini;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatcherDemo {
	
	public static void main(String[] args) {
		
		String input = "Shop,Mop,Hopping,Shopping";
		
		Pattern p = Pattern.compile("hop");
		
		Matcher m = p.matcher(input);
	
		//exact match required
		//System.out.println(m.matches());
		
		//substring required
		//System.out.println(m.find());
		
		//to find the pattern
		while(m.find()) {
			
			
			//returns the pattern
			System.out.print(m.group());
			
			System.out.print(" "+m.start());
			
			System.out.println(" "+m.end());
			
			
			
		}
	}

}
