package com.capg;

public class Wrapper {

	public static void main(String args[])
	{
		
		
		int i =10;//Primitive data type
		
		//boxing - Primitive to Object
		Integer i1 = new Integer(i);//Object type 
		
		Integer i2 =10; //autoboxing - alternate way
		
		//unboxing - Object to primitive
		int result = i1.intValue();
		
		System.out.println(i);
	}
}
