import java.io.*;
import java.util.*;
public class Source {
    static Object lock = new Object();
    static Scanner sc = new Scanner(System.in);
    static int n=0;
	static int fact=1;
    
    public static void main(String[] args) {

    	//First Thread
        Thread t1 = new Thread(new Runnable() {
            public void run() {
                // complete this function!
            	// For Serializability using lock object
            	synchronized (lock) {
                	//Take number as input
                	n = sc.nextInt();
                }
            }
        });

        //Second Thread
        Thread t2 = new Thread(new Runnable() {
            public void run() {
                // complete this function!
            	// For Serializability using lock object
            	synchronized (lock) {
            		
            		//logic to calculate factorial
                	if(n>=0) {
                		for(int i=1;i<=n;i++) {
                    		fact = fact*i;
                    	}
                		
                	}
                }
            }
        });

        try {
            t1.start();
            t2.start();
            //wait until execution of previous thread ends
            t1.join();
            t2.join();
            //Print the value
            System.out.println(fact);
        } catch (Exception e) {
            System.out.println("An exception has occured!");
        }
    }
 
}