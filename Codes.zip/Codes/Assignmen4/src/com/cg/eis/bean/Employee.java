package com.cg.eis.bean;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.pl.GenerateOutput;

public class Employee {

	  public String name;
	  double salary;
	  String id;
	  String Designation;
	  public String InsuranceScheme;



	public Employee(String name, int salary, String id, String Designation) {
		// TODO Auto-generated constructor stub
		
		super();
		this.name = name;
		this.salary = salary;
		this.id = id;
		this.Designation = Designation;
		getInsuranceScheme(salary);
	}


	private String getInsuranceScheme(double salary){
	    //Write your code here
	    //should return the schemes as schemen a, scheme b, scheme c, no scheme
	    //, null or raise an exception.
		  
		  
		  
		  if(this.salary>5000 && this.salary<20000) {
			  //Designation = "System Associate";
			  InsuranceScheme = "scheme c";
		  }
		  else if(this.salary>=20000 && this.salary<40000) {
			  //Designation = "Programmer";
			  InsuranceScheme = "scheme b";
		  }
		  else if(this.salary>=40000) {
			  //Designation = "System Associate";
			  InsuranceScheme = "scheme a";
			  
		  }
		  else if(this.salary<5000){
			  //Designation = "Clerk";
			  InsuranceScheme = "no insurance";			 
		  }
		
		  	return InsuranceScheme;		  

	  	}

	  	
	  	public String getName() {
	  		return name;
	  	}


	  	public void setName(String name) {
	  		this.name = name;
	  	}


	  	public String getId() {
	  		return id;
	  	}


	  	public void setId(String id) {
	  		this.id = id;
	  	}


	  	public String getDesignation() {
	  		return Designation;
	  	}


	  	public void setDesignation(String designation) {
	  		Designation = designation;
	  	}


	  	public String getInsuranceScheme() {
	  		return InsuranceScheme;
	  	}


	  	public void setInsuranceScheme(String insuranceScheme) {
	  		InsuranceScheme = insuranceScheme;
	  	}
	  	

		public double getSalary() {
	  		return salary;
	  	}

	  	public void setSalary(double salary) {
	  		this.salary = salary;
	  	}

	public String getEmployeeDetails() {
	    //Write your code here 
	    //Should return a String in the below format
	   //Name: name Id: id Salary: salary Designation: Designation InsuranceScheme: InsuranceScheme
		  return "Name: " + this.name + " Id: " + this.id + " Salary: " + this.salary + " Designation: " + Designation + " InsuranceScheme: " +InsuranceScheme;
	  }

	
		public static void main(String[] args) throws EmployeeException {
			
			Employee emp = new Employee("Ritvik", 3999, "E1", "SA1");
			String  s = emp.getEmployeeDetails();
			System.out.println(s);
			
			GenerateOutput g = new GenerateOutput();
			int  i = g.getmaxMedicalInsurance(emp);
			System.out.println(i);
		}
	
	}
