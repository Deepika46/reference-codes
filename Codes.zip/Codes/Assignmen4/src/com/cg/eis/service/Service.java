package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

interface EmployeeService {
  //Write your code here
	int SchemeCBal = 1000;
	int SchemeBBal = 5000;
	int SchemeABal = 15000;
	
	public static int maxMedicalInsurance(Employee e1) {
		return 0;
	}
	
	

}


public class Service implements EmployeeService {

	
	
	public static int maxMedicalInsurance(Employee e1) throws EmployeeException {
		
		if(e1.getSalary()<3000) {
			  throw new EmployeeException();
		  }
		
		  if(e1.getSalary()>5000 && e1.getSalary()<20000) {
			  return SchemeCBal;
		  }
		  else if(e1.getSalary()>=20000 && e1.getSalary()<40000) {
			  return SchemeBBal;
		  }
		  else if(e1.getSalary()>=40000) {
			  return SchemeABal;
		  }
		  else{
			  return 0;
		  }
		  
	}
	
}
