package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.Service;

public class GenerateOutput extends Service{
	
	public int getmaxMedicalInsurance(Employee e1) throws EmployeeException {
		return Service.maxMedicalInsurance(e1);		
	}
	
	

}
