package com.cg.eis.exception;
import java.lang.Exception;

public class EmployeeException extends Exception{
	
	public EmployeeException() {
		
		// TODO Auto-generated constructor stub
		System.err.println("Your Salry is less than 3000. Not applicable for Insurance");
	}
	
	
	
	
}
