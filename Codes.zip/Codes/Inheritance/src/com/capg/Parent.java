package com.capg;

public class Parent {

	int pid=200;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	

	}

	
	public Parent() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Parent Constructor");
	}
}
