package com.capg;

public class Child extends Parent{

	int cid =100;
	
	public Child() {
		// TODO Auto-generated constructor stub
		
		
		System.out.println("Child Constructor");
	 
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parent  p = new Parent();//has a relationship
		
		//System.out.println(p.pid);
		
		//Create Object of the child
		Child c = new Child();
		
		//Access Parent Properties
		//System.out.println(c.pid);
		
		//Access Grandparent Properties
		//System.out.println(c.hashCode());
		
		Parent p1 = new Child();//Polymorphism
		
		Object o1 = new Child();//Polymorphism
		
		
		
		//Parent accessing properties of the child
		Child c1 = (Child) new Parent();
		
		
		System.out.println(c1.pid);
		
		
	

	}
}
