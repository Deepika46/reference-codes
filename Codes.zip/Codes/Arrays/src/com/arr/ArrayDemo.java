package com.arr;

public class ArrayDemo {
	
	int ar[];
	
	public static void main(String[] args) {
		
		//Creating array direct declare values
		int ar[] = {1,2,3,4,5}; //one D
		
		
		System.out.println(ar.length);
		
		// Compulsory declare size
		//Create array using new operator...object type
		int ar1[] = new int [6]; 
		
		ar1[1] = 54;
		ar1[2] = 43;
		ar1[4] = 35;
		
		System.out.println(ar1.length );
		
		for(int i=0;i<ar1.length;i++)
		{
			System.out.print(ar1[i]+ " ");
		}
		
		System.out.println();
		
		//foreach loop
		int j = 2;
		for(int i : ar1)
		{
			System.out.print(i+ " ");
			
		}
		
	}

}
