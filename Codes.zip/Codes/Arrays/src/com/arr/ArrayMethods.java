package com.arr;
import java.util.Arrays;


public class ArrayMethods {

	public static void main(String[] args) {
		
		int j=0;
		int sqaures[] = {2,3,5,6,67,7};
		
		//(Arrays.binarySearch returns the index of the element
		//System.out.println(Arrays.binarySearch(sqaures, 67));
		
		//copy elements
		int num[] = Arrays.copyOf(sqaures, 3);
		for(int i : num)
		{
			System.out.println(i);
		}
		
		//copy of array start & end point
		/*int num1[] = Arrays.copyOfRange(sqaures, 1, 4);
		for(int i : num1)
		{
			System.out.println(i);
		}

		*/
		
		Arrays.fill(sqaures, 4);
		for(int i : sqaures)
		{
			System.out.println(i);
		}
	}
}
