package com.arr;

public class TwoDimentional {
	
public static void main(String[] args) {
		
		//Creating array direct declare values
		int ar2[][] = {{1,2},{3,4}};//2D
		
		
		System.out.println(ar2.length);
		
		// Compulsory declare size
		//Create array using new operator...object type
		int ar1[][] = new int [3][2]; 
		
		//System.out.println(ar1); //op =  [[I@15db9742
		System.out.println(ar1[1]); //op = [I@15db9742
		
		
	}
}
