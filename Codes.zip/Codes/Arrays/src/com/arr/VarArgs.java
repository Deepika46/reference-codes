package com.arr;


import static java.lang.System.*;


public class VarArgs {
	
	static void print(int a,int y, String... s) {
		
		out.println(a +","+y);
		
		for(int i=0;i<s.length;i++) {
			out.print(s[i] +"\t");
			out.println();
		}
	}
	
	public static void main(String[] args) {
		
		
		float result = 10/3.0f;
		out.println(result);
		print(3,2,"java", "java5");
		out.println("Next invoke");
		print(1,2,"s","cfd","fd","fed");
		
		
		
	}

}
