package com.capgemini;
import java.util.*;


class Emp implements Comparable{
	
	int EmpID;
	String Ename;
	double Sal;
	static int i;
	
	public Emp() {
		// TODO Auto-generated constructor stub
		EmpID = i++;
		Ename = "Unknown";
		Sal = 0.0;
	}
	

	public Emp(String ename, double sal) {
		super();
		EmpID = i++;
		Ename = ename;
		Sal = sal;
	}

	public String toString() {
		return "EmpID : " + EmpID + "\t" + "Ename : " + Ename + "\t" + "Sal : " + Sal;
	}
	
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		if(this.Sal == ((Emp)o).Sal)
			return 0;
		else if(this.Sal > ((Emp)o).Sal)
			return 1;
		else
			return -1;
	}
	
	
}

public class ComparatorDemo {
	
	public static void main(String[] args) {
		//Emp e1 = new Emp("harry", 40000.00);
		Set<Emp> ts1 = new TreeSet<Emp>();
		ts1.add(new Emp("harry",40000.00));
		ts1.add(new Emp("Mary",20000.00));
		ts1.add(new Emp("Peter",50000.00));
		
		Iterator itr = ts1.iterator();
		while(itr.hasNext()) {
			Object element = itr.next();
			System.out.println(element + "\n");
		}
		System.out.println();
			
		}
		
		
	}
	
	
