import java.util.HashMap;

class Source{
	
	public HashMap<Integer,Integer> getSquares(int numbers[]){
		
		//Create new HashMap to store values
		HashMap<Integer,Integer> m = new HashMap<Integer,Integer>();
	
		for(int i=0;i<numbers.length;i++) {
			
			//store values as key-number, value-square in HashMap object
			m.put(numbers[i], numbers[i]*numbers[i]);
			
		}//End of For loop
		
		//return HashMap Object
		return m;
	    
	}//end of getSquares method
	
	public static void main(String[] args) {		
		
		//Declare & initialize array
		int num[] = {1,3,4,5,6};
		
		//HashMap to store returned Object
		HashMap<Integer,Integer> m = new HashMap<Integer,Integer>();
		
		//Object of Source class to access getSquares method
		Source s =new Source();
		m = s.getSquares(num);
		
		System.out.println(m.values());
		
	}//end of the main
}//end of the Source class