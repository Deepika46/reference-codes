package abstracta;

public class Vehicle {
	
	public Vehicle() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Inside Vehicle Constructor");
	}

	int maxSpeed = 120;
	
	public void Print()
	{
		int i =10;
		System.out.println("Inside Parent Method");
	}
}
