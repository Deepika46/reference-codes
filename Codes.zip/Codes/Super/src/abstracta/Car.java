package abstracta;

public class Car extends Vehicle{
	
	
	public Car() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Inside Child Constructor");
	}
	
	int maxSpeed = 180;
	
	void display()
	{
		super.Print();
	}
	
	@Override
	public void Print()
	{
		
		int i = 20;
		System.out.println("Inside Child Method");
	}
	
	public static void main(String[] args) {
		
		Vehicle V = new Vehicle();	
		
		 
		//Car c1 =(Car) new Vehicle();
		
	}
}
