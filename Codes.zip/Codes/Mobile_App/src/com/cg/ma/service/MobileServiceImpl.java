package com.cg.ma.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cg.ma.dao.DBUtil;
import com.cg.ma.dao.MobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.exceptions.MobileException;

public class MobileServiceImpl implements MobileService {
	
	private MobileDao mdao = new MobileDaoImpl();
	//private Purchase p = new Purchase();
	

	@Override
	public long insertCustomer(Purchase purchase) throws MobileException {
		// TODO Auto-generated method stub
		mdao.insertCustomer(purchase);
		return purchase.getpId();
	}

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return mdao.getAllMobiles();
	}

	@Override
	public boolean deleteMobile(long mobId) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.deleteMobile(mobId);
	}

	@Override
	public boolean searchMobile(double mobPrice) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.searchMobile(mobPrice);
		
	}

	@Override
	public boolean updateMobile(long mobId) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.updateMobile(mobId);
	}

	@Override
public boolean validateRegistrationDetails(Purchase purchase) throws MobileException {
		// TODO Auto-generated method stub
		
		if(!purchase.getcName().matches("[A-Z][a-z]{4,20}")) {
			throw new MobileException("Customer Name should start start with capital letter");
			
		}
		if(!purchase.getMailId().matches("[a-z0-9._]+@[a-z0-9.]+[a-z]{2,3}"))
		{			
			throw new MobileException("Customer emailid should be valid");
		}
		
		
		if(!purchase.getPhone().matches("[0-9]{10}"))
		{			
			throw new MobileException("Customer emailid should be valid");
		}
		
		
        String MobileIdAsString = Long.toString(purchase.getMobId());
		
		 if(!MobileIdAsString.matches("[0-9]{4}"))
         {
             System.err.println("Invalid id");
             return false;
         }
     
     try {
         String sql = "SELECT COUNT(*) FROM mobiles WHERE mobileid=?";
        Connection conn = DBUtil.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql);
         pst.setLong(1, purchase.getMobId());
         ResultSet rst = pst.executeQuery();
         if(rst.next()) {
             
             long count = rst.getLong(1);
             if(count==1)
             {
                 return true;
             }
             else {
               //  throw new MobileException("Invalid mobile id ");
            	   System.err.println("Invalid id Not in database");
                   return false;
             }
         }
         
     } catch (SQLException e) {
         // TODO: handle exception
         throw new MobileException("Problem in validation of mobile"+e.getMessage());
     }
     
    
		return true;
	}
	
	
	
	
	
}


