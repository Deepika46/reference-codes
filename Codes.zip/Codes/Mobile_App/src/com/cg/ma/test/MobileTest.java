package com.cg.ma.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.ma.dto.Purchase;
import com.cg.ma.exceptions.MobileException;
import com.cg.ma.service.MobileService;
import com.cg.ma.service.MobileServiceImpl;

class MobileTest {

	
	
	@Test
	void RegisterTest() throws MobileException {
		Purchase p=new Purchase();
		MobileService mser = new MobileServiceImpl();
		
		p.setcName("Vinayak");
		p.setMailId("abc@gmail.com");
		p.setMobId(1001);
		p.setPhone("9869262626");
		
		mser.insertCustomer(p);
		
		
		
		
	
	}

}
