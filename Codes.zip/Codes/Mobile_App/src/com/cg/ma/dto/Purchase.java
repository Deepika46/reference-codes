package com.cg.ma.dto;

import java.time.LocalDate;

public class Purchase {
	private long pId;
	private String cName;
	private String mailId;
	private String phone;
	private LocalDate pDate;
	private long mobId;
	
	public Purchase()
	{
		
	}

	public Purchase(long pId, String cName, String mailId, String phone, LocalDate pDate,long mobId) {
		super();
		this.pId = pId;
		this.cName = cName;
		this.mailId = mailId;
		this.phone = phone;
		this.pDate = pDate;
		this.mobId = mobId;
	}



	/**
	 * @return the pId
	 */
	public final long getpId() {
		return pId;
	}

	/**
	 * @param l the pId to set
	 */
	public final void setpId(long l) {
		this.pId = l;
	}

	/**
	 * @return the cName
	 */
	public final String getcName() {
		return cName;
	}

	/**
	 * @param cName the cName to set
	 */
	public final void setcName(String cName) {
		this.cName = cName;
	}

	/**
	 * @return the mailId
	 */
	public final String getMailId() {
		return mailId;
	}

	/**
	 * @param mailId the mailId to set
	 */
	public final void setMailId(String mailId) {
		this.mailId = mailId;
	}

	/**
	 * @return the phone
	 */
	public final String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public final void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the pDate
	 */
	public final LocalDate getpDate() {
		return pDate;
	}

	/**
	 * @param pDate the pDate to set
	 */
	public final void setpDate(LocalDate pDate) {
		this.pDate = pDate;
	}

	/**
	 * @return the mobId
	 */
	public final long getMobId() {
		return mobId;
	}

	/**
	 * @param mobId the mobId to set
	 */
	public final void setMobId(long mobId) {
		this.mobId = mobId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Purchase [pId=" + pId + ", cName=" + cName + ", mailId=" + mailId + ", phone=" + phone + ", pDate="
				+ pDate + ", mobId=" + mobId + "]";
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	
	

}
