package com.cg.ma.dto;

public class Mobile {

	
		private long mobId;
		private String mobName;
		private double mobPrice;
		private String mobQuant;
		
		public Mobile()
		{
			
		}
		
		public Mobile(long mobId, String mobName, double mobPrice, String mobQuant) {
			super();
			this.mobId = mobId;
			this.mobName = mobName;
			this.mobPrice = mobPrice;
			this.mobQuant = mobQuant;
		}

		/**
		 * @return the mobId
		 */
		public final long getMobId() {
			return mobId;
		}
		/**
		 * @param l the mobId to set
		 */
		public final void setMobId(long l) {
			this.mobId = l;
		}
		/**
		 * @return the monName
		 */
		public final String getMobName() {
			return mobName;
		}
		/**
		 * @param monName the monName to set
		 */
		public final void setMobName(String mobName) {
			this.mobName = mobName;
		}
		/**
		 * @return the mobPrice
		 */
		public final double getMobPrice() {
			return mobPrice;
		}
		/**
		 * @param mobPrice the mobPrice to set
		 */
		public final void setMobPrice(double mobPrice) {
			this.mobPrice = mobPrice;
		}
		/**
		 * @return the mobQuant
		 */
		public final String getMobQuant() {
			return mobQuant;
		}
		/**
		 * @param mobQuant the mobQuant to set
		 */
		public final void setMobQuant(String mobQuant) {
			this.mobQuant = mobQuant;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "Mobile [mobId=" + mobId + ", mobName=" + mobName + ", mobPrice=" + mobPrice + ", mobQuant="
					+ mobQuant + "]";
		}
	
		
		
}
