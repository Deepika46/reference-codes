package com.cg.ma.logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.exceptions.MobileException;

public class MobileLogger {
	static Logger Logger;
	public static Logger getLogger() throws MobileException {
		if(Logger==null) {
			Logger=Logger.getLogger("RegLogger");
			FileInputStream fin;
			try {fin=new FileInputStream("./resource/log4j.properties");
		}catch (FileNotFoundException e) {
			throw new MobileException("Property file for logger"+"not found"+e.getMessage());
		};
		PropertyConfigurator.configure(fin);
		
	}return Logger;

}
}