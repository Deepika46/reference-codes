package com.abstracteg;

public abstract class Shape {

	abstract public void draw();//hidden, No defination
	
	public void Display()
	{
		System.out.println("Concrete Class");
	}
	
	//Not possible to create object for abstract method
	//Shape s =new Shape(); 
}

