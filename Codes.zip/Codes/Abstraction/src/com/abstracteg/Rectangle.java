package com.abstracteg;

public class Rectangle extends Shape{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
		System.out.println("Draw Rectangle");
	}

	public static void main(String[] args) {
		
		Shape rect = new Rectangle();
		rect.Display();//Hidden method
		rect.draw();
	}
}
