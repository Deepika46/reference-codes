package com.cg;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class ConsumSupply {

	public static void main(String[] args) {
		
		Supplier<String> mySupplier = ()->"Welcome to CG";
		System.out.println(mySupplier.get());
		
		Consumer<String> myConsumer = (str)->System.out.println(str.length());
		myConsumer.accept("Capgegmini");
		
		Predicate<Integer> myPredicate = (x)->x>100;
		int i = 1;
		if(myPredicate.test(i)) {
			System.out.println("Greater than 100");
		}
		else {
			System.out.println("Less than 100");
		}
		
		Predicate<Integer> myPredicate2 = (x) -> x<500;
		Predicate<Integer> myPredicate3 = myPredicate.and(myPredicate2);
		
		int t =250;
		System.out.println(myPredicate3.test(t));
		
		Function<String, Integer> myfunction = (str)->(str.indexOf('a'));
		System.out.println(myfunction.apply("Capgemini"));
	}
}
