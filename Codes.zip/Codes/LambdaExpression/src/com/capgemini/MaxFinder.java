package com.capgemini;

public interface MaxFinder {

	int maximum(int num1, int num2);
	
}
