package com.capgemini.print;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class App {

	public static void main(String[] args) {
		Iprint i = ()->System.out.println("Hello");
		i.Greeet();
		
		Supplier<String> s = ()->"ABC";
		System.out.println(s.get());
		
		Consumer<String> c= (x)->System.out.println(x);
		c.accept("Vinayak");
		
		Predicate<Integer> p = x->x>10;
		boolean result = p.test(10);
		System.out.println(result);
		
		
		BiPredicate<Integer, Integer> b =(x,y)->x>y;
		boolean result2 = b.test(10,20);
		System.out.println(result2);
		
		Function<String, Integer> f = x->x.length();
		int result3= f.apply("CagG");
		System.out.println(result3);
		
		List<String> list = new ArrayList<String>();
		
		list.add("Vinayak");
		list.add("Swastika");
		list.add("Yogesh");
		list.add("Radha");
		
		/*for (String str : list) {
			System.out.println(str);
		}*/
		
		//alternate way using expression
		//list.forEach(x->System.out.println(x));
		
		//another simple way
		list.forEach(System.out::println);
		
		
	}
	
}
