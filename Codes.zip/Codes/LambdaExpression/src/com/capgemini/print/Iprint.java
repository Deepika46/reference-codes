package com.capgemini.print;

import java.util.function.Supplier;

public interface Iprint {
	void Greeet();
	
	
}
