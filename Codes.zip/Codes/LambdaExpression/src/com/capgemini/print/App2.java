package com.capgemini.print;

public class App2 {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		IAdd add = cal::add;
	
		int result = add.addNumbers(10,20);
		System.out.println(result);
	}
	
}
