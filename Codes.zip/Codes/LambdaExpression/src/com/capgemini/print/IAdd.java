package com.capgemini.print;

public interface IAdd {
	
	int addNumbers(int num1,int num2);

}
