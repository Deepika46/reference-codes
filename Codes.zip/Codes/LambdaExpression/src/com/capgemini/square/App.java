package com.capgemini.square;

public class App {

	public static void main(String[] args) {
		
		ICalculateSquare cal = (x)->x*x;
		
		System.out.println(cal.CalSquare(25));
	}
}
