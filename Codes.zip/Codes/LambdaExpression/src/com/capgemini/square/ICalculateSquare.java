package com.capgemini.square;

public interface ICalculateSquare {
	
	int CalSquare(int x);

}
