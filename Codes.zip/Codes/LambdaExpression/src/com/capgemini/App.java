package com.capgemini;

public class App {

public static void main(String[] args) {
		
		/*MaxFinder m = new MaxFinderImple();
		System.out.println(m.maximum(10, 20));
		*/
	
		//lamda Expression
		//(x,y) Parameter list
		MaxFinder m = (x,y)->x>y?x:y;
		
		//(x,y)->x>y?x:y; Perform the implementation of the functional interface
		int max = m.maximum(10, 20);
		System.out.println(max);
		
	
	}
}
