package com.capgemini;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Calculator {
    public long add (long number1, long number2){
return number1 + number2; 
}
}