package com.capgemini;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculatorTest {

	@Test
	 public void add() throws Exception {
		  Calculator cal=new Calculator();
		  assertEquals(4, cal.add(1,3));
		}

}
