package vinayak;

import java.util.Set;
import java.util.TreeSet;

class CreateObject
{
public static void main(String []args)
{
Set set = new TreeSet();
set.add("Priya");
set.add("Ritu");
set.add(100);
}
}
