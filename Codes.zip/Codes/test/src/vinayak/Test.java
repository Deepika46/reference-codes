package vinayak;

import java.util.*;
import java.util.*;
public class Test {
public static void main(String[] args) {
 Set set = new TreeSet();
 set.add("anu");
 set.add("anil");
 set.add("sunil");
 for(Object str:set){
 System.out.print(str + " ");}
}
}