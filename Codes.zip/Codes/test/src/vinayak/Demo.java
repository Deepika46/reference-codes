package vinayak;

import java.nio.file.Path;
import java.nio.file.Paths;

class Demo{
public static void main(String []args){
Path javaHome = Paths.get("C:/Program Files/Java/jdk1.8.0_25");
  System.out.println(javaHome.getNameCount());}
}
