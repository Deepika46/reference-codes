package com.overriding;

public class Child extends Parent{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child c = new Child();
		c.display(200);
		
		Parent p1 = new Parent();
		p1.display(34);
		
		
	}
	
	@Override 
	/*used to override. If we make 
	changes in parent display parameters it must 
	get reflected in the child*/
	public void display(int i) {
		System.out.println("Child I = "+i);
	}

}
