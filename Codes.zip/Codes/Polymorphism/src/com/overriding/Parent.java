package com.overriding;

public class Parent {
	
	public static void main(String[] args) {
		
	}


	public void display(int  i) {
		// TODO Auto-generated method stub
		
		System.out.println("Parent I = "+i);
		
	}
}
