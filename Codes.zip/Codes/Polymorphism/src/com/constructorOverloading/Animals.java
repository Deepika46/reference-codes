package com.constructorOverloading;

public class Animals {
	
	int aid;
	String aname;
	String acolor;
	
	
	public Animals() {
		// TODO Auto-generated constructor stub
		
		this.aid = 1;
		this.aname = "Lion";
		this.acolor = "Yellow";
	}
	
	public Animals(int aid) {
		// TODO Auto-generated constructor stub
		this.aid = aid;
		this.aname = "Tiger";
		this.acolor = "Yellow";
	}
	
	public Animals(int aid, String aname) {
		// TODO Auto-generated constructor stub
		this.aid = aid;
		this.aname = aname;
		this.acolor = "Brown";
	}
	
	public Animals(int aid, String aname, String acolor) {
		// TODO Auto-generated constructor stub
		this.aid = aid;
		this.aname = aname;
		this.acolor = acolor;
	}
	
	public void Print(){
		System.out.println(this.aid);
		System.out.println(this.aname);
		System.out.println(this.acolor);
	}
	
	public static void main(String[] args) {
		
		Animals lion = new Animals();
		Animals tiger = new Animals(2);
		Animals horse = new Animals(3,"Horse");
		Animals elephant = new Animals(4,"Elephant","Grey");
		
		lion.Print();
		tiger.Print();
		horse.Print();
		elephant.Print();
	}

}
