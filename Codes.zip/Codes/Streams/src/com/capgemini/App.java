package com.capgemini;

import java.util.stream.Stream;

public class App {
	
	public static void main(String[] args) {
		
		Stream<Integer> s = Stream.of(2,23,54,656,76,45,45,345,345,345,34);
		//s.forEach(System.out::println);
		s.filter(x->x%2==0).forEach(System.out::println);
	}

}
