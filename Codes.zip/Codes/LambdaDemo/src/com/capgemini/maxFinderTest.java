package com.capgemini;

public class maxFinderTest {
	
	public static void main(String[] args) {
		
		//Interfacename variable = (Parameters)->Implementation
		MaxFinder finder = (x,y)->x>y?x:y;
		
		//call method in the interface class
		int result = finder.maximum(32, 43);
		
		System.out.println(result);
	}

}
