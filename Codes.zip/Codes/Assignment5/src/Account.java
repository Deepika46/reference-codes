class Person {
    
    public String name;
    public float age;
    
    // Default Constructor
    Person() {
        
    }
    
    // Parameterized Constructor
    public Person(String name, float age) {
    	this.name= name;
    	this.age= age;
    }
    
    //Getters and Setters
    public void setname(String name) {
         this.name= name;
    }
     
    public String getname() {
         return this.name;
    }
    
    public void setage(float age) {
         this.age= age;
    }
    
    public float getage(){
         return this.age;
    }
}




abstract class Account {
    
	long accNum = 18785;
	double balance;
	Person accHolder = new Person();	
       
	// Parameterized Constructor
	public Account(String name, float age, double balance) {
		getPerson().setage(age);
        getPerson().setname(name);
        this.balance= balance;
    }
	
	//Getters and Setters
	public void deposit(double rupees) {
        balance= balance+ rupees;
    }    
    
    public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getPerson() {
		return accHolder;
	}

	public void setPerson(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	
	//Abstract method - Withdraw - Check Condition
	public abstract void withdraw(double rupees);

	//Display the result
    public String toString() {
    	// Should return the string in the format:
        // Name: TempName Age: 68.0 AccNumber: 1333339438704 Balance= 899.0
    	String result = " ";
    	
    	result += "Name: "+ accHolder.getname()+" ";
    	result += "Age: "+ accHolder.getage()+" ";
    	result += "Accnumber: "+ this.accNum+" ";
        result += "Balance: "+this.balance+" ";
        return result;
    }

  
    //Same as Parameterized Constructor
    public void setAccountDetails(String name, float age, double balance) {
    	// Set the account details for the account holder
        accHolder.setname(name);
        accHolder.setage(age);
        this.balance=balance;
    }
  
    public static void main( String args[]){
    	Account a = new SavingAccount("TempName",68,899);
    	System.out.println(a);  
    }
}




class SavingAccount extends Account {
	 
	 	 
	 int minBalance =500;
	 
	 //Constructor
	 public SavingAccount(String name, float age, double balance) {
		 super(name,age,balance);
		// TODO Auto-generated constructor stub
	 }
	 
	 //Definition of the Abstract method withdraw
	 public void withdraw(double bal){
		 
	     if(this.balance-bal>=minBalance) {
	    	 this.balance = this.balance - bal;	 
	     }
	     else {
	    	 System.out.println("Can't Withdraw");
	     }
	     
	 }	 
	 
}
	



class CurrentAccount extends Account {
	 
	int OverDraftLimit = -2000;
	
	//Constructor
	public CurrentAccount(String name, float age, double balance) {
	 	// TODO Auto-generated constructor stub
	 	super(name, age, balance);
	}
	
	//Definition of the Abstract method withdraw
	public void withdraw(double bal){
	     
		if(this.balance-bal>=OverDraftLimit) {	     
			this.balance = this.balance - bal;	 
	     
	     }
	     else {
	    	 System.out.println("Can't Withdraw");
	     }	 
	}
	
}


