package com.capgemini;

class Account {
    
    
    public Account(double balance) {
     super();
     this.balance = balance;
 }
 double balance;
    boolean withdraw(double bal){
         this.balance = this.balance - bal;
         return true;
       }
    
    
 @Override
 public String toString() {
     return "Account [balance=" + balance + "]";
 }


 public static void main(String[] args) {
     Account a = new SavingAccount(2000);
     Boolean b = a.withdraw(2000);
     System.out.println(b);
       System.out.println(a);
 }
}
class SavingAccount extends Account {
 
 public SavingAccount(double balance) {
     // TODO Auto-generated constructor stub
     super(balance);
 }
 
 int minBalance =500;
 boolean withdraw(double bal){
     if(this.balance-bal>=minBalance) 
     {
          
     
     this.balance = this.balance - bal;
 
     return true;
     }
     else return false;
     
   }
 
 
}
class CurrentAccount extends Account {
 public CurrentAccount(double balance) {
     // TODO Auto-generated constructor stub
     super(balance);
     
 }
 int OverDraftLimit = -2000;
 boolean withdraw(double bal){
     
     if(this.balance-bal>=OverDraftLimit) 
     {
          
     
     this.balance = this.balance - bal;
 
     return true;
     }
     else return false;
     
   }

 
 
}
