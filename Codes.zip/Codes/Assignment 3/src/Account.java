class Person {
    
    public String name;
    public float age;
    Person()
    {
        
    }
    public Person(String name, float age)
    {
        this.name= name;
        this.age= age;
    }
     public void setname(String name)
     {
         this.name= name;
     }
     public String getname()
     {
         return this.name;
     }
     public void setage(float age)
     {
         this.age= age;
     }
     public float getage()
     {
         return this.age;
     }
}
    



class Account {
    
       long accNum = 18785;
       double balance;
       Person accHolder = new Person();
       
       public long setaccNum()
       {
           return this.accNum;
       }
       
       public Account(String name, float age, double balance)
       {
    	   getPerson().setage(age);
    	   getPerson().setname(name);
    	   this.balance= balance;
       }
    
       public Account(double balance) {
    	   // TODO Auto-generated constructor stub
    	   this.balance = balance;
       }
       
       public void deposit(double rupees)
       {
    	   balance= balance+ rupees;
       }
    
    
    
       boolean withdraw(double bal){
    	   
    	   this.balance = this.balance - bal;
    	   return true;
       }

    public String toString() {
      String result = " ";
      result += "Name: "+ accHolder.getname()+" ";
       result += "AGE: "+ accHolder.getage()+" ";
        result += "Account Number: "+ this.accNum+" ";
         result += "Balance: "+this.balance+" ";
         return result;
      
    // Should return the string in the format:
    // Name: TempName Age: 68.0 AccNumber: 1333339438704 Balance= 899.0
  }

  public double getBalance() {
      return this.balance;
    // Should return the balance present in the Account
  }
  
  public void setBalance(double bal){
    // Set the balance for the account holder
     this.balance= bal;
  }  

  public void setAccountDetails(String name, float age, double balance) {
    // Set the account details for the account holder
    accHolder.setname(name);
    accHolder.setage(age);
    this.balance=balance;
  }
  
  public Person getPerson(){
    // return the AccountHolder
    return this.accHolder;
  }
  public static void main( String args[])
  {
	  Account SavingAccount = new SavingAccount(900);
      System.out.println(SavingAccount);
      
  }
}

class SavingAccount extends Account{

	public final float minBalance = 500;
	
	public SavingAccount(String name, float age, double balance) {
		super(name, age, balance);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	 boolean withdraw(double bal){
	    if(this.balance - bal >= minBalance)
	    {
	    	this.balance = this.balance - bal;
	    	return true;
	    }
	    else
	    	return false;
	    
	  }
	
	public SavingAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}
}

class CurrentAccount extends Account{
	
	float OverDraftLimit = -2000;

	public CurrentAccount(String name, float age, double balance) {
		super(name, age, balance);
		// TODO Auto-generated constructor stub
	}
	
	public CurrentAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}
			
	@Override
	boolean withdraw(double bal){
		if(this.balance - bal >= OverDraftLimit)
		{
			this.balance = this.balance - bal;
			return true;
		}
			
		else
			return false;		    
	  }
	
	
}
