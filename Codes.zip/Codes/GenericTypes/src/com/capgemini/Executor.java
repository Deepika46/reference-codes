package com.capgemini;

public class Executor {
	
	public static void main(String[] args) {
		
		//create a sender to send string message
		Sender<String> stringSender = new Sender<String>();
		stringSender.setMessage("Hello from Java!");
		stringSender.sendMessage();
		
		//create an email object to be sent using sender
		Email myEmail = new Email();
		myEmail.setFrom("abc@gmail.com");
		myEmail.setTo("xyz@gmail.com");
		myEmail.setSubject("Sub");
		myEmail.setBody("ddfefddgdgf");
		
		//Create a sender to send this email
		
		Sender<Email> emailSender = new Sender<Email>();
		emailSender.setMessage(myEmail);
		emailSender.sendMessage();
		
		
		Employee e = new Employee();
		
			e.setEid(101);
			e.setEname("Vinayak");
			e.setSal(500000);
			
		Sender<Employee> empSender = new Sender<Employee>();
		
		empSender.setMessage(e);
		empSender.getMessage();                                                                                                        
		
		
	}

}
