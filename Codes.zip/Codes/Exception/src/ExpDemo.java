
public class ExpDemo {
	
	public static void main(String[] args) {
		
	ExpDemo expObj = new ExpDemo();
	
	expObj.openFile();
	
	//handling in the calling Function
	/*expObj.writeInfo();*/
	
	//handle in the caller function\	
	try {
		expObj.writeInfo();
	}
	catch(Exception e)
	{
		System.err.println("Divide by 0 Error");
	}
	
	expObj.closeFile();
			
	}
	
	public void openFile() {
		System.out.println("File Opened");
	}
	
	
	//public void writeInfo()
	public void writeInfo() throws Exception{
		
		
		
		
		//handle in the caller function
		int filesize = 45/0;
		
		//handle in the calling Function
		/*try {
			int filesize = 45/0;
		}
		
		catch(Exception e)
		{
			System.err.println("Divide by 0 Error");
		}*/
		
		/*catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}*/
		
		System.out.println("Data is Written into the file");
	}
	
	public void closeFile() {
		System.out.println("File is Closed");
	}
			

}
