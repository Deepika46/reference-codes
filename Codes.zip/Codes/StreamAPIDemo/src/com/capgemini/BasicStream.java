package com.capgemini;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BasicStream {

	public static void main(String[] args) {
		
		//Stream with static data
		//Stream<String> stream = Stream.of("I","S","D","E","H");		
		//stream.forEach((abc)->System.out.println(abc));
		
		//Stream aquired from array
		List<String> locations = Arrays.asList(new String[] {"Pune","Mumbai","Banglore","Pune"});
		//stream = locations.stream();	
		Stream<String> stream = locations.stream();	
		
		//Method1
		//stream.forEach(System.out::println);
		
		//Mehtod2
		//locations.stream().map(String::length).forEach(System.out::println);
		//locations.stream().map(str->str.length()).forEach(System.out::println);
		
		//List<String> result = stream.filter((location)->location.length()>5).collect(Collectors.toList());
		//result.stream().forEach((city)->System.out.println(city));
		
		
		List <Integer> intList = Arrays.asList(5,7,8,23,64,34,23,65);
		Optional<Integer> result2 = intList.stream().filter((a)->a>0).reduce((a,b)->a>b?a:b);
		System.out.println("Highest NO : "+result2.get());
		
		List<String> result3 = stream.distinct().collect(Collectors.toList());
		result3.stream().forEach((city)->System.out.println(city));
			
	}
}
