package com.capgemini;

import java.util.logging.Logger;

public class LogDemo {

	public static void main(String[] args) {
		
		Logger logger = Logger.getRootLogger();
		//Logger.getLogger(LogDemo.class.getClass());
		
			PropertyConfigurator.configure("dgdf/gfdg/dfdg/fdfgd.properties");
			
				logger.info("this is from info");
				logger.error("this is from error");
	}
}
