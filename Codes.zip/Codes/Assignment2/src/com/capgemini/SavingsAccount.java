package com.capgemini;

public class SavingsAccount extends Account{
	
	

}
