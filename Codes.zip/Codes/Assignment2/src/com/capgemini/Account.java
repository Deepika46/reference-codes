package com.capgemini;

public class Account {
	
	long accNum;
	double balance, minbalance=500;
	Person accHolder = new Person();
	
	public Account() {
		
		accHolder.setName(null);
    	accHolder.setAge(0);
    	this.balance = 0.0; 
	}
	
	public Account(String name, float age, double balance){
		
		accHolder.setName(name);
    	accHolder.setAge(age);
    	this.balance = balance; 
	}
	
	
	
	
	// complete the class
    public void deposit(double rupees) {
    	// Set the balance of the account after the money is deposited to the account
    	this.balance = this.balance + rupees;
    }

    public void withdraw(double rupees) {
    	// Set the balance of the account after the money is withdrawn from the account
    	if(this.balance - rupees < minbalance)
    	{
    		System.out.println("Can't Withdraw");
    	}
    	else
    		this.balance = this.balance - rupees;
    }



    @Override
	public String toString() {
		return "Name: " + accHolder.getName() + " Age: " + accHolder.getAge() + " AccNumber: " + this.accNum + " Balance: "+ this.balance;
	}

	public double getBalance() {
		return this.balance;
    	// Should return the balance present in the Account
    }

    public void setBalance(double bal){
    	// Set the balance for the account holder
    	this.balance = bal;
    	
    }  

    public void setAccountDetails(String name, float age, double balance) {
    	// Set the account details for the account holder
    	accHolder.setName(name);
    	accHolder.setAge(age);
    	this.balance = balance;    	
    }

    public Person getPerson(){
		return accHolder;
    	// return the AccountHolder
    }

    
    public static void main(String[] args) {
		
    	Account a1 = new Account();
    	a1.setAccountDetails("Vinayak", 21, 50000.00);
    	a1.setAccNum(1000011234);
    	String s = a1.toString();
    	System.out.println(s);
    	
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getMinbalance() {
		return minbalance;
	}

	public void setMinbalance(double minbalance) {
		this.minbalance = minbalance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
}
