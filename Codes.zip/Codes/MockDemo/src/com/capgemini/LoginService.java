package com.capgemini;

public interface LoginService {
	boolean login(String username, String password);
}
