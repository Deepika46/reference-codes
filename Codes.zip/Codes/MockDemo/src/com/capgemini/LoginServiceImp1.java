package com.capgemini;

public class LoginServiceImp1 implements LoginService {

	private UserDao userDao;
	
	public void setUserDao(UserDao userDao) {
		this.userDao =userDao;
	}
	
	@Override
	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		boolean valid = false;
		
		try {
			User user = userDao.loadByUserNameAndPassword(username,password);
			if(user != null) valid = true;
			
		}
		catch(Exception e) {}
			return valid;
	}

}
	

