package com.capgemini;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.Before;
import org.junit.jupiter.api.Test;

class LoginTest {

	private LoginServiceImp1 service;
	private UserDao mockDao;
	
	@Before
	public void setup() {
		service = new LoginServiceImp1();
		mockDao = EasyMock.createMock(UserDao.class);
		service.setUserDao(mockDao);		
	}
	
	@Test
	public void testLogin() {
		User user = new User();
		String username = "testusername";
		String password = "testpassword";
		
		EasyMock.expect
	}
	
	
	@Test
	void test() {
		fail("Not yet implemented");
	}

}
