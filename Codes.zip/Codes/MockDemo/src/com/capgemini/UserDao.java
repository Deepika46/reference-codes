package com.capgemini;

public interface UserDao {
	User loadByUserNameAndPassword(String username, String password);

}
