package com.capgemini;

public class User {
	String username, password;

}
