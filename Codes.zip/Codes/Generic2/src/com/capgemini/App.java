package com.capgemini;

import java.util.ArrayList;
import java.util.List;

public class App {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		list.add("ABC");
		list.add("ABCD");
	}
}
