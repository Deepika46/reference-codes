package com.capgemini;

public class UtilClass<T> {
	
	public boolean areEqual(T i,T j) {
		return i.equals(j);
		
	}

}
